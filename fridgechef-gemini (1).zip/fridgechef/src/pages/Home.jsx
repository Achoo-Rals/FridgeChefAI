import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import UploadArea from '@/components/UploadArea';
import { Sparkles, ChefHat, UtensilsCrossed } from 'lucide-react';

const STEPS = [
  { emoji: '📸', title: 'Snap a photo', desc: 'Take a picture of your fridge or pantry — drag, browse, or use your camera.' },
  { emoji: '🔍', title: 'Confirm ingredients', desc: 'Our AI scans your photo and lists what it found. Add or remove anything in a tap.' },
  { emoji: '🍳', title: 'Cook & enjoy', desc: 'Get personalized recipe ideas with full instructions. Filter by diet, time, and more.' },
];

// Converts a File object into a base64 string (no "data:image/...;base64," prefix)
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function Home() {
  const navigate = useNavigate();
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadedImageUrl, setUploadedImageUrl] = useState(null);
  const [error, setError] = useState(null);

  const handleFileSelected = async (file) => {
    setIsAnalyzing(true);
    setError(null);
    setUploadedImageUrl(null);

    try {
      // Show a local preview immediately (no need to upload anywhere first)
      const previewUrl = URL.createObjectURL(file);
      setUploadedImageUrl(previewUrl);

      const imageBase64 = await fileToBase64(file);

      const response = await fetch('/api/invoke-llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: "You are a culinary AI assistant. Analyze this image of the inside of a fridge or pantry. Identify all visible food ingredients. Return a concise list of ingredient names (e.g. 'eggs', 'baby spinach', 'cheddar cheese', 'chicken breast'). Be specific enough to be useful but keep each item short. If you can see it, list it. Do not include quantities.",
          imageBase64,
          schema: {
            type: "object",
            properties: {
              ingredients: { type: "array", items: { type: "string" } }
            }
          }
        })
      });

      if (!response.ok) throw new Error('Request failed');

      const result = await response.json();
      const ingredients = result?.ingredients || [];
      navigate('/ingredients', { state: { ingredients, imageUrl: previewUrl } });
    } catch (err) {
      console.error(err);
      setError('Hmm, we couldn\u2019t analyze that photo. Please try again with a clearer image.');
      setIsAnalyzing(false);
      setUploadedImageUrl(null);
    }
  };

  return (
    <div>
      <section className="relative overflow-hidden">
        <div className="absolute top-10 -left-10 w-64 h-64 rounded-full bg-primary/8 blur-3xl" />
        <div className="absolute top-20 right-0 w-72 h-72 rounded-full bg-accent/10 blur-3xl" />

        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 pt-12 sm:pt-20 pb-16">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-5">
                <Sparkles className="w-4 h-4" /> AI-powered recipe finder
              </div>
              <h1 className="font-heading font-extrabold text-4xl sm:text-5xl lg:text-6xl leading-[1.05] tracking-tight text-foreground">
                Snap your fridge.<br /><span className="text-accent">Get recipes instantly.</span>
              </h1>
              <p className="mt-5 text-lg text-muted-foreground max-w-md leading-relaxed">
                Take a photo of your fridge or pantry, and our AI will identify your ingredients and suggest delicious meals you can cook right now.
              </p>
              <div className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-1.5"><ChefHat className="w-4 h-4 text-primary" /> No more "what to cook"</span>
                <span className="inline-flex items-center gap-1.5"><UtensilsCrossed className="w-4 h-4 text-primary" /> Personalized to your diet</span>
              </div>
            </div>

            <div>
              <UploadArea onFileSelected={handleFileSelected} isAnalyzing={isAnalyzing} uploadedImageUrl={uploadedImageUrl} />
              {error && <p className="mt-3 text-sm text-destructive text-center">{error}</p>}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-card/50 border-y border-border/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
          <div className="text-center mb-12">
            <h2 className="font-heading font-bold text-3xl text-foreground">How it works</h2>
            <p className="mt-2 text-muted-foreground">Three simple steps from fridge to feast</p>
          </div>
          <div className="grid sm:grid-cols-3 gap-8">
            {STEPS.map((step, i) => (
              <div key={i} className="text-center">
                <div className="relative mx-auto w-20 h-20 rounded-3xl bg-gradient-to-br from-primary/12 to-accent/12 flex items-center justify-center mb-4">
                  <span className="text-4xl select-none">{step.emoji}</span>
                  <div className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-heading font-bold flex items-center justify-center">{i + 1}</div>
                </div>
                <h3 className="font-heading font-bold text-lg text-foreground">{step.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed max-w-xs mx-auto">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
